---
title: Reproducibilidad
nav_order: 5
---

## Protocolo público

- Procedimiento de captura con sellos T=0/24h/72h.
- Registro auditable con columna **Notas**.
- Datos sintéticos de ejemplo para reproducir figuras.
- Controles nulos (RE-Q).

> Los datos crudos y layouts de hardware no se publican aquí.
