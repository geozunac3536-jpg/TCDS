---
title: Marco teórico
nav_order: 2
---

## Sinopsis

- Postulados operativos y campos efectivos.
- Puentes con el SM/GR vía EFT, positividad y PPN.
- Predicciones auditablemente diferenciables.

### Referencias públicas
- Preprints, DOIs y repositorios espejo (añadir enlaces).
