---
title: Panorama
nav_order: 1
---

# TCDS — Teoría Cromodinámica Sincrónica

Esta es la **documentación pública** del proyecto TCDS. Delimita hipótesis contrastables, rutas de falsación y métricas ΣMP sin exponer detalles sensibles.

**Alcance**:
- Sinopsis verificable del marco teórico.
- Σ-metrics (ΣMP) y KPIs.
- Protocolos de laboratorio de alto nivel.
- Matriz de decisión EXO-12.
- Trazabilidad legal y de autoría.

> Para datos y hardware propietarios use el espejo privado.
