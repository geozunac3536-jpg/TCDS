---
title: EXO-12
nav_order: 4
---

## Matriz de decisión

1. Consistencia intra-métrica.
2. Controles nulos superados.
3. Convergencia multi-modal.
4. Reproducibilidad cruzada.

**Resultado**: Aceptar / Revisión mayor / Rechazar, con trazabilidad.
