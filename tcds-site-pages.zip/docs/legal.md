---
title: Legal y ética
nav_order: 6
---

## Licencias

- **Código**: AGPL-3.0.
- **Documentos**: CC BY-NC-ND 4.0.

## Trazabilidad

- INDAUTOR, DOI y `MANIFEST.json` con huellas SHA256.

## Divulgación responsable

Ver `SECURITY.md` del repositorio.
