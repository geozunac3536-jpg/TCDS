---
title: Σ-metrics
nav_order: 3
---

## Definiciones ΣMP

- **R(t)**: correlación temporal.
- **LI**: índice de locking de fase.
- **RMSE_SL**: error en ajuste de sincronización.
- **Ventanas p:q**: lenguas de Arnold.
- **κΣ**: parámetro de medio efectivo.

### KPIs mínimos
LI ≥ 0.9, R > 0.95, RMSE_SL < 0.1, reproducibilidad ≥ 95%.
